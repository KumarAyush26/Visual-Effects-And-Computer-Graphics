"Jiggly Bubble Free" is owned by Moonflower Carnivore (http://u3d.as/cxf) and published on Unity Asset Store. 
As per End User License Agreement of Asset Store (https://unity3d.com/legal/as_terms), you are strictly prohibitied from reproducing, distributing or sub-licensing this asset.
For more information, please refer to the online asset description page: http://u3d.as/sew
This asset has a paid version with more particle effects for different situation: http://u3d.as/sae

To use the "bubble cubemap" material properly, replace the "cubemap test" by any formal cubemap in similar 6 frames layout.
"Bubble cubemap skybox" requires a skybox or reflective probe already assigned in your scene. The corresponding shaders are written to simulate 3D environmental reflection on billboard particles.

Please email us (moonflowercarnivore@gmail.com) for any inquiry.


「弹性泡泡免费版 / Jiggly Bubble Free」由Moonflower Carnivore (http://u3d.as/cxf) 持有并于Unity官方资源商店公开。
根据Unity资源商店的终端用户协议 (https://unity3d.com/legal/as_terms)，阁下严禁在任何场合（Unity资源商店或第三方网络空间）再发行本资源，不论免费或付费、修改与否。
请参阅资源说明页获取更多信息：http://u3d.as/sew
本免费资源存在付费版本提供更多适合不同场合的气泡效果：http://u3d.as/sae

如使用素材「bubble cubemap」，请将预设的「cubemap test」替换成正式的立方体贴图，其6格展开编排应该类似於cubemap test。
「bubble cubemap skybox」须要场景中已经设置了天空盒或反射探头，对应的两个着色器都是为了在平板粒子上模拟立体场景反射效果。

如有疑问请电邮至 moonflowercarnivore@gmail.com 。